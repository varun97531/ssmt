import os

conversion_dict = {"O": 'zero', 'Z': 'zero', '1': 'one', '2': 'two', '3': 'three', '4': 'four',
                   '5': 'five', '6': 'six', '7': 'seven', '8': 'eight', '9': 'nine'}

root_directory = "/home/varun/Desktop/SSMT/SSMTDigits/TRAIN/"

def convert_text(s):
    result = ""
    for c in s:
        result += conversion_dict.get(c, c) + " "
    return result[:-1]

def get_full_path(path, name):
    return os.path.join(path, name)

def get_id(path, name):
    return get_full_path(path, name)[len(root_directory):-4].replace('/', '-')


with open('wav.scp', 'w') as w:
    with open('text', 'w') as t:
        for path, subdirs, files in os.walk(root_directory):
            for name in files:
                if name[-4:] == '.wav':
                    transcription = convert_text(name[:-5])
                    utt_id = get_id(path, name)
                    total_path = get_full_path(path, name)
                    total_path = total_path.replace(desktop_ssmt_path, '')
                    w.write(f"{utt_id} {total_path}\n")
                    t.write(f"{utt_id} {transcription}\n")
